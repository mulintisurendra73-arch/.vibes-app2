CREATE TABLE users (
 id UUID PRIMARY KEY,
 username TEXT UNIQUE NOT NULL,
 display_name TEXT NOT NULL,
 avatar_url TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE rooms (
 id UUID PRIMARY KEY,
 host_user_id UUID NOT NULL REFERENCES users(id),
 name TEXT NOT NULL,
 topic TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE wallet_ledger (
 id UUID PRIMARY KEY,
 user_id UUID NOT NULL REFERENCES users(id),
 type TEXT NOT NULL,
 coins BIGINT NOT NULL,
 reference_id TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE reports (
 id UUID PRIMARY KEY,
 reporter_user_id UUID NOT NULL REFERENCES users(id),
 target_user_id UUID REFERENCES users(id),
 room_id UUID REFERENCES rooms(id),
 reason TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
