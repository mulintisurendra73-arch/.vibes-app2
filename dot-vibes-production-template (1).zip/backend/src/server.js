require("dotenv").config();
const express=require("express"),helmet=require("helmet"),cors=require("cors");
const app=express(); app.use(helmet()); app.use(cors()); app.use(express.json());

const rooms=[];
const ledger=[];

app.get("/health",(req,res)=>res.json({ok:true,service:". vibes"}));
app.get("/api/rooms",(req,res)=>res.json({rooms}));
app.post("/api/rooms",(req,res)=>{
 const {name,host,topic}=req.body||{};
 if(!name||!host)return res.status(400).json({error:"name and host are required"});
 const room={id:"room_"+Date.now(),name,host,topic:topic||"Community",listeners:0};
 rooms.push(room); res.status(201).json(room);
});
app.post("/api/rooms/:id/report",(req,res)=>{
 const {reason}=req.body||{};
 if(!reason)return res.status(400).json({error:"reason required"});
 res.status(201).json({accepted:true});
});
app.post("/api/users/:id/block",(req,res)=>res.status(201).json({blocked:true,userId:req.params.id}));
app.get("/api/users/:id/wallet",(req,res)=>res.json({userId:req.params.id,coins:0,earnings:0,currency:"INR"}));
app.post("/api/wallet/topup",(req,res)=>res.status(501).json({error:"PAYMENT_PROVIDER_CONFIGURATION_REQUIRED"}));
app.post("/api/gifts",(req,res)=>res.status(501).json({error:"WALLET_AND_GIFT_LEDGER_CONFIGURATION_REQUIRED"}));

app.listen(Number(process.env.PORT||8080),()=>console.log(". vibes API running"));
