package com.dotvibes.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg=Color(0xFF090A0F)
private val Card=Color(0xFF141620)
private val Accent=Color(0xFFB45CFF)

data class Room(val id:String,val name:String,val host:String,val listeners:Int,val topic:String)

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{VibesApp()}}
}

@Composable fun VibesApp(){
    var tab by remember{mutableIntStateOf(0)}
    MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Card,primary=Accent)){
        Scaffold(containerColor=Bg,bottomBar={
            NavigationBar(containerColor=Card){
                listOf("Home" to Icons.Default.Home,"Rooms" to Icons.Default.Mic,
                    "Reels" to Icons.Default.PlayArrow,"Chat" to Icons.Default.Chat,
                    "Profile" to Icons.Default.Person).forEachIndexed{i,p->
                    NavigationBarItem(tab==i,{tab=i},{Icon(p.second,p.first)},label={Text(p.first)})
                }
            }
        }){pad->Box(Modifier.padding(pad)){
            when(tab){0->Home();1->Rooms();2->Reels();3->Chat();else->Profile()}
        }}
    }
}

@Composable fun Title(t:String,s:String){Column(Modifier.padding(20.dp)){Text(t,28.sp,fontWeight=FontWeight.Bold);Text(s,color=Color.LightGray)}}

fun demoRooms()=listOf(
 Room("1","Late Night Vibes","Aarav",128,"Music • Friends • Chill"),
 Room("2","Telugu Talks","Priya",74,"Talk • Fun • Community"),
 Room("3","Gaming Zone","Rahul",56,"Games • Voice chat")
)

@Composable fun Home(){LazyColumn{item{Title(". vibes","Meet people. Join live conversations.")};items(demoRooms()){RoomCard(it)}}}
@Composable fun Rooms(){LazyColumn{item{Title("Live rooms","Join a room and start talking.")};items(demoRooms()){RoomCard(it)}}}
@Composable fun RoomCard(r:Room){Card(Modifier.padding(16.dp,7.dp).fillMaxWidth(),colors=CardDefaults.cardColors(Card),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(54.dp).clip(CircleShape).background(Accent),contentAlignment=Alignment.Center){Text(r.host.take(1))};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(r.name,fontWeight=FontWeight.Bold);Text(r.topic,color=Color.LightGray);Text("${r.listeners} listeners",color=Color.Gray,fontSize=12.sp)};Icon(Icons.Default.ChevronRight,"Open")}}}
@Composable fun Reels(){Column(Modifier.fillMaxSize()){Title("Reels","Short videos from the community");Box(Modifier.fillMaxWidth().weight(1f).padding(20.dp).clip(RoundedCornerShape(24.dp)).background(Card),contentAlignment=Alignment.Center){Text("Production media feed integration")}}}
@Composable fun Chat(){Column{Title("Messages","Private conversations");Text("Realtime chat is provided by the production backend.",Modifier.padding(20.dp),color=Color.LightGray)}}
@Composable fun Profile(){Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Spacer(Modifier.height(30.dp));Box(Modifier.size(100.dp).clip(CircleShape).background(Accent),contentAlignment=Alignment.Center){Text("V",36.sp,fontWeight=FontWeight.Bold)};Text("Your . vibes profile",24.sp,fontWeight=FontWeight.Bold);Text("@username",color=Color.Gray);Spacer(Modifier.height(20.dp));Button({}){Text("Edit profile")};OutlinedButton({}){Text("Wallet & earnings")}}}
