# Release procedure

1. Configure Firebase and production backend.
2. Configure audio provider and payment provider.
3. Verify moderation and account deletion.
4. Create a release signing/upload key and store it securely.
5. Run:
   `./gradlew bundleRelease`
6. Inspect the generated `.aab`.
7. Upload to Play Console internal testing.
8. Complete required testing.
9. Complete Play Console declarations.
10. Promote the tested release to production.

Never commit signing keys or provider secrets to GitHub.
