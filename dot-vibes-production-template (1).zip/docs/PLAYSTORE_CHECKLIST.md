# . vibes Play Store checklist

## Code
- [x] API 36 target
- [x] Permanent application ID: com.dotvibes.app
- [x] Release version: 1.0.0
- [x] GitHub-safe .gitignore
- [x] INTERNET permission
- [x] RECORD_AUDIO permission
- [x] POST_NOTIFICATIONS permission

## External configuration — owner must complete
- [ ] Google Play Console developer account
- [ ] Identity/account verification
- [ ] App/package registration
- [ ] Firebase project
- [ ] Audio provider account
- [ ] Payment provider account
- [ ] Production database
- [ ] Production domain/privacy-policy URL
- [ ] Signing/upload key
- [ ] Store listing graphics
- [ ] Data Safety questionnaire

## Testing — owner/team must complete
- [ ] Internal test
- [ ] Closed test
- [ ] Required tester participation
- [ ] Crash/ANR review
- [ ] Real-device audio testing
- [ ] Payment test transactions
- [ ] Account deletion test
- [ ] Report/block/moderation test

## Production
- [ ] Signed AAB
- [ ] Privacy policy published
- [ ] Terms/community guidelines published
- [ ] Content rating completed
- [ ] Data Safety completed accurately
- [ ] Target audience completed
- [ ] Store listing completed
- [ ] Production access granted
- [ ] Release submitted
