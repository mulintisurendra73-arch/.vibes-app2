# . vibes privacy policy template

Replace every `[PLACEHOLDER]` with your real business/provider information before publishing.

## Information collected
Describe account information, profile information, messages, uploaded media, device/diagnostic data, notifications, payment information, and live-room information actually collected.

## How information is used
Describe authentication, social features, live rooms, messaging, moderation, security, notifications and payments.

## Sharing
List every third-party service that receives data, such as authentication, cloud storage, analytics, audio and payment providers.

## Retention and deletion
Explain retention periods and how users request account/data deletion.

## Contact
[LEGAL BUSINESS NAME]
[EMAIL]
[COUNTRY/ADDRESS]

This template is not legal advice. Have the final policy reviewed for your actual implementation and jurisdiction.
