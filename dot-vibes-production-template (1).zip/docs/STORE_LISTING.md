# . vibes Play Store listing draft

## App name
.vibes

## Short description
Meet people, join live conversations and share your vibe.

## Long description
.vibes is a social community app for live conversations, profiles, messaging and short-form community content.

Users can discover live rooms, participate in conversations, connect with other members and manage their profile.

Only publish features that are actually enabled in the production build.

## Support
[SUPPORT WEBSITE]
[SUPPORT EMAIL]
