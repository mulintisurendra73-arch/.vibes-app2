# Moderation requirements

Production social features should provide:
- Report user/content/room
- Block user
- Mute room participant
- Host remove participant
- Admin review queue
- Audit log
- Rate limiting
- Spam controls
- Community guidelines
- Account/data deletion
